<?php

$_MODULE = array(
    'weatherinfo' => 'Weather Information',
    'Location' => 'Location',
    'Temperature in Celsius' => 'Temperature in Celsius',
    'Temperature in Fahrenheit' => 'Temperature in Fahrenheit',
    'Humidity' => 'Humidity',
    'Description' => 'Description'
);

?>
