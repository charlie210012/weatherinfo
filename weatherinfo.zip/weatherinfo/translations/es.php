<?php

$_MODULE = array(
    'weatherinfo' => 'Información del Clima',
    'Location' => 'Ubicación',
    'Temperature in Celsius' => 'Temperatura en Celsius',
    'Temperature in Fahrenheit' => 'Temperatura en Fahrenheit',
    'Humidity' => 'Humedad',
    'Description' => 'Descripción'
);

?>
